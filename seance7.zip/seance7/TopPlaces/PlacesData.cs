﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Media.Imaging;

namespace TopPlaces
{
    public class PlacesData
    {
        private IList<Place> placesList;

    

        public PlacesData()
        {
            string pathProject = Environment.CurrentDirectory;
            Place p1 = new Place(pathProject + "/photos/bruxelles.jpg", "Bruxelles");
            Place p2 = new Place(pathProject + "/photos/paris.jpg", "Paris");
            Place p3 = new Place(pathProject + "/photos/moscou.jpg", "Moscou");
            Place p4 = new Place(pathProject + "/photos/amsterdam.jpg", "Amsterdam");
            Place p5 = new Place(pathProject + "/photos/newyork.jpg", "New York");

            PlacesList = new List<Place>();
            PlacesList.Add(p1);
            PlacesList.Add(p2);
            PlacesList.Add(p3);
            PlacesList.Add(p4);
            PlacesList.Add(p5);
        }

        public IList<Place> PlacesList { get { MessageBox.Show(""+placesList.ElementAt(0).NbVotes); return placesList; } set => placesList = value; }





    }

    public class Place
    {
        private string _description;
        private string _pathImageFile;
        private int _nbVotes;
        private Uri _uri;
        private BitmapFrame _image;
        

        public Place(string path, string description)
        {
            Description = description;
            _pathImageFile = path;
            _nbVotes = 0;
            _uri = new Uri(_pathImageFile);
            _image = BitmapFrame.Create(_uri);
        }

        public string Description { get => _description; set => _description = value; }
        public string PathImageFile { get => _pathImageFile; set => _pathImageFile = value; }
        public int NbVotes { get { return _nbVotes; MessageBox.Show("coucou"); } }
        public Uri Uri { get => _uri; set => _uri = value; }
        public BitmapFrame Image { get => _image; set => _image = value; }
    }
}
